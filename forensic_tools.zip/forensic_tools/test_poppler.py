from pdf2image import convert_from_bytes

# Optional: if you are on Windows and Poppler is not on PATH
poppler_path = r"C:\Program Files\poppler-23.11.0\bin"  # change this if needed

pdf_path = "example.pdf"

with open(pdf_path, "rb") as f:
    try:
        images = convert_from_bytes(f.read(), poppler_path=poppler_path)
        print("✅ Got", len(images), "page(s) successfully converted!")
    except Exception as e:
        print("❌ Error:", e)

