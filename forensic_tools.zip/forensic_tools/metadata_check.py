# forensic_tools/metadata_check.py
from PIL import Image
from PIL.ExifTags import TAGS
import os
import datetime 
import io # New import for string handling

def check_metadata(file_path):
    """
    Extracts file system and image metadata, returning both structured data and an HTML string.
    """
    results = {}
    html_output = ""
    
    try:
        # --- 1. File System Metadata Check (Always Available) ---
        file_stats = os.stat(file_path)
        
        # Capture HTML output for Section 2
        html_output += "<h4>File System Metadata:</h4>"
        html_output += f"<ul><li><strong>File Size (Bytes):</strong> {file_stats.st_size}</li>"
        html_output += f"<li><strong>Creation Time:</strong> {datetime.datetime.fromtimestamp(file_stats.st_ctime)}</li>"
        html_output += f"<li><strong>Modification Time:</strong> {datetime.datetime.fromtimestamp(file_stats.st_mtime)}</li></ul>"
        
        # --- 2. EXIF (Image) Metadata Check ---
        img = Image.open(file_path)
        exif_data = img._getexif()
        
        if exif_data:
            html_output += "<h4>EXIF (Image) Metadata:</h4><ul>"
            
            # Standard Tag Extraction
            for tag_id, value in exif_data.items():
                tag = TAGS.get(tag_id, tag_id)
                if isinstance(tag, str) and tag in ['DateTimeOriginal', 'Make', 'Model', 'Software', 'Artist']:
                    results[tag] = value
                    html_output += f"<li><strong>{tag}:</strong> {value}</li>"
            
            html_output += "</ul>"

            # Forensic Checks (for scoring)
            software_tag = results.get('Software', '').lower()
            if 'photoshop' in software_tag or 'gimp' in software_tag or 'picasa' in software_tag:
                results['TAMPER_ALERT'] = "High"
                html_output += "<p class='alert-high'><strong>[METADATA ALERT]</strong> 'Software' tag suggests editing with known manipulation tools.</p>"
        
        else:
            html_output += "<p>[INFO] No EXIF Metadata found (Common for PNG or converted PDF/scans).</p>"
            
    except Exception as e:
        html_output += f"<p class='alert-high'>[META ERROR] Metadata check failed: {e}</p>"

    # Return structured data and the HTML string
    return results, html_output

def check_file_signature(file_path):
    # This function remains unchanged (returns structured data, not HTML)
    results = {}
    try:
        with open(file_path, 'rb') as f:
            hex_data = f.read(16).hex() 
        
        if hex_data.startswith('ffd8ffe'):
            signature_status = "JPEG (OK)"
        elif hex_data.startswith('89504e47'):
            signature_status = "PNG (OK)"
        elif hex_data.startswith('25504446'): # Check for PDF signature
            signature_status = "PDF (OK)"
        else:
            signature_status = f"UNKNOWN/SUSPICIOUS (Starts with: {hex_data[:8]}...)"
            
        results = {"HEX_DATA": hex_data, "SIGNATURE_STATUS": signature_status}

    except Exception as e:
        results = {"HEX_DATA": "ERROR", "SIGNATURE_STATUS": f"Error reading file: {e}"}
    
    return results