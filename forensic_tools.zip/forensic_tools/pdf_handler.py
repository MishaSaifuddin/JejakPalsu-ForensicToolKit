import os
from pdf2image import convert_from_path

def convert_pdf_to_images(pdf_path, output_folder="temp_pdf_images"):
    """
    Converts a PDF file into a list of PIL Image objects (one per page).
    Returns a list of temporary file paths for the converted images.
    """
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
        
    try:
        # Converts PDF pages to PIL Image objects
        images = convert_from_path(pdf_path)
        
        temp_paths = []
        for i, image in enumerate(images):
            # Save the image as a temporary JPEG file
            temp_path = os.path.join(output_folder, f"{os.path.basename(pdf_path)}_page_{i+1}.jpg")
            image.save(temp_path, 'JPEG')
            temp_paths.append(temp_path)
        
        return temp_paths

    except Exception as e:
        print(f"  [PDF ERROR] Conversion failed. Ensure Poppler is installed and in your PATH. Error: {e}")
        return None