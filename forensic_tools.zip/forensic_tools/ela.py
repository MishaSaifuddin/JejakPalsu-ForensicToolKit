# forensic_tools/ela.py (This code is correct and safe)
import os
from PIL import Image, ImageChops, ImageEnhance

def perform_ela(image_path, quality=90):
    """
    Performs Error Level Analysis (ELA) and returns the resulting PIL Image.
    
    ELA works by resaving the image at a known quality (e.g., 90) and 
    calculating the difference between the original and the resaved version. 
    Areas that are uniform in the original image will have low errors (dark), 
    while newly added/manipulated areas (which haven't been compressed before) 
    will have high errors (bright). 
    """
    temp_file = "temp_ela_copy.jpg"
    
    try:
        # 1. Load Original Image
        original_img = Image.open(image_path).convert('RGB')
        
        # 2. Save a Recompressed Copy
        # Resaving at a lower quality amplifies the compression artifacts.
        original_img.save(temp_file, 'JPEG', quality=quality)
        
        # 3. Load the Recompressed Copy
        resaved_img = Image.open(temp_file).convert('RGB')
        
        # 4. Calculate the Absolute Difference (Error Level)
        ela_img = ImageChops.difference(original_img, resaved_img)
        
        # 5. Enhance the Error Image for Visibility (Normalization)
        extrema = ela_img.getextrema()
        # Find the maximum difference across all bands (R, G, B)
        max_diff = max([ex[1] for ex in extrema])
        
        if max_diff == 0:
            print("  [ELA WARNING] No measurable difference found. Image may be a clean save or already heavily compressed.")
            return ela_img
        
        # Scale factor normalizes the maximum difference to 255 (full white)
        scale_factor = 255.0 / max_diff
        ela_img = ImageEnhance.Brightness(ela_img).enhance(scale_factor)
        
        # Optional: Increase contrast slightly
        ela_img = ImageEnhance.Contrast(ela_img).enhance(1.2)
        
        # 6. Clean up the temporary file
        os.remove(temp_file)
        
        return ela_img

    except Exception as e:
        if os.path.exists(temp_file):
            os.remove(temp_file)
        print(f"  [ELA ERROR] Failed to process image: {e}")
        return None

if __name__ == '__main__':
    # This block is for testing the module directly
    print("This module contains the ELA function and should be run via main.py.")