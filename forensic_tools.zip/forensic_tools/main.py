import argparse
import os
import sys
import datetime
import webbrowser
from forensic_tools.ela import perform_ela
from forensic_tools.metadata_check import check_metadata, check_file_signature
from forensic_tools.pdf_handler import convert_pdf_to_images
from forensic_tools.html_report import generate_html_report


def run_forensic_analysis(file_path):
    
    if not os.path.exists(file_path):
        print(f"\n[ERROR] File not found: {file_path}")
        return

    original_file_path = file_path
    temp_image_paths = None
    
    # Data collection structure for HTML report
    # FIX: 'evidence' is now a dictionary containing a 'findings' list
    report_data = {
        'sections': {
            'hex': {}, 
            'metadata': {}, 
            'ela': {}, 
            'evidence': {'findings': []} # <-- FIX APPLIED HERE
        }, 
        'summary': {}
    }
    
    # --- FILE TYPE CHECK AND CONVERSION ---
    if file_path.lower().endswith('.pdf'):
        print("[INFO] PDF file detected. Converting to JPEG image for analysis...")
        temp_image_paths = convert_pdf_to_images(file_path)
        
        if temp_image_paths:
            file_path = temp_image_paths[0] 
            print(f"[INFO] Analyzing first page image: {file_path.split(os.path.sep)[-1]}")
        else:
            print("[ERROR] Could not convert PDF. Analysis terminated.")
            return

    # --- FORENSIC ANALYSIS (COLLECT DATA) ---
    tamper_score = 0
    
    # 1. HEX FILE & SIGNATURE ANALYSIS
    hex_results = check_file_signature(original_file_path)
    report_data['sections']['hex'] = {'signature': hex_results['SIGNATURE_STATUS'], 'data': hex_results['HEX_DATA']}
    
    if "SUSPICIOUS" in hex_results['SIGNATURE_STATUS']:
        tamper_score += 3
        # FIX: Append to 'findings' list
        report_data['sections']['evidence']['findings'].append("🔴 **HEX ALERT:** File signature is suspicious or inconsistent with the file extension.")

    # 2. EXIF & Metadata Analysis
    metadata_results, metadata_html = check_metadata(file_path)
    report_data['sections']['metadata']['content'] = metadata_html

    if metadata_results.get('TAMPER_ALERT') == "High":
        tamper_score += 4
        # FIX: Append to 'findings' list
        report_data['sections']['evidence']['findings'].append(f"🔴 **METADATA ALERT:** 'Software' tag suggests editing with commercial tools ({metadata_results.get('Software')}).")

    # 3. Error Level Analysis (ELA)
    output_ela_filename = "N/A"
    ela_result_img = perform_ela(file_path)
    
    if ela_result_img:
        output_ela_filename = f"ELA_Result_{os.path.basename(file_path)}"
        ela_result_img.save(output_ela_filename)
        
        # FIX: Append to 'findings' list
        report_data['sections']['evidence']['findings'].append("🟡 **ELA PENDING:** Manual review of ELA_Result file is required to confirm splicing/copy-move forgery.")
    
    report_data['sections']['ela']['output_filename'] = output_ela_filename


    # --- GENERATE SUMMARY & HTML REPORT ---
    max_score = 10 
    tamper_percentage = min(100, (tamper_score / max_score) * 100)

    if tamper_score >= 4:
        conclusion = "TAMPERING LIKELY (HIGH CONCERN)"
        conclusion_color = "red"
    elif tamper_score > 0:
        conclusion = "SUSPICION NOTED (LOW CONCERN)"
        conclusion_color = "orange"
    else:
        conclusion = "TAMPERING UNLIKELY"
        conclusion_color = "green"
        
    # Format evidence for HTML
    evidence_list_html = ""
    # FIX: Iterate over 'findings' list
    if report_data['sections']['evidence']['findings']:
        for item in report_data['sections']['evidence']['findings']:
            css_class = 'alert-high' if '🔴' in item else ('alert-low' if '🟡' in item else 'alert-info')
            evidence_list_html += f'<li class="{css_class}">{item}</li>\n'
    else:
        evidence_list_html = '<li><span class="alert-info">**Pristine:** No strong automated flags for metadata or hex manipulation detected.</span></li>'
        
    # Finalize Report Data
    # FIX: Assign 'content' as a key within the 'evidence' dictionary
    report_data['sections']['evidence']['content'] = evidence_list_html 
    report_data['summary'] = {
        'conclusion': conclusion,
        'conclusion_color': conclusion_color,
        'tamper_percentage': f"{tamper_percentage:.1f}"
    }

    # GENERATE AND OPEN HTML
    html_path = generate_html_report(original_file_path, report_data)

    if html_path:
        print(f"\n[SUCCESS] HTML report saved to: {html_path}")
        webbrowser.open_new_tab(html_path)
    
    # --- CLEANUP ---
    if temp_image_paths:
        try:
            temp_dir = os.path.dirname(temp_image_paths[0])
            for f in os.listdir(temp_dir):
                os.remove(os.path.join(temp_dir, f))
            os.rmdir(temp_dir)
            print(f"[INFO] Cleaned up temporary PDF image folder: {temp_dir}")
        except Exception as e:
            print(f"[INFO] Could not clean up temp files: {e}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description="A Digital Forensic Tool for detecting image tampering in receipts and documents."
    )
    parser.add_argument(
        "file_path", 
        type=str, 
        help="The full path to the document or receipt image file (e.g., /path/to/receipt.jpg or /path/to/doc.pdf)"
    )
    
    args = parser.parse_args()
    run_forensic_analysis(args.file_path)