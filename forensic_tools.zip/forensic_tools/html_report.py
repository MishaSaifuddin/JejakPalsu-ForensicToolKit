# forensic_tools/html_report.py
import os
import webbrowser

def generate_html_report(original_file, report_data, html_filename="forensic_report.html"):
    """
    Generates a complete HTML report file from the forensic analysis data.
    """
    
    sections = report_data['sections']
    summary = report_data['summary']
    
    html_content = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Forensic Report: {os.path.basename(original_file)}</title>
        <style>
            body {{
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                margin: 20px;
                background-color: #f4f7f6;
                color: #333;
            }}
            .container {{
                max-width: 900px;
                margin: 0 auto;
                background: #fff;
                padding: 30px;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            }}
            h2 {{
                border-bottom: 2px solid #ddd;
                padding-bottom: 10px;
                color: #1e88e5;
                margin-top: 30px;
            }}
            h3, h4 {{
                color: #555;
            }}
            .summary-box {{
                border: 2px solid #28a745;
                background-color: #e6ffec;
                padding: 20px;
                border-radius: 6px;
                margin-bottom: 20px;
            }}
            .conclusion {{
                font-size: 1.5em;
                font-weight: bold;
                color: {summary['conclusion_color']};
            }}
            .evidence-list li {{
                margin-bottom: 8px;
                list-style-type: none;
            }}
            .alert-high {{ color: red; font-weight: bold; }}
            .alert-low {{ color: orange; }}
            .alert-info {{ color: green; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🧾 Forensic Report</h1>
            <p style="font-size: 1.2em; border-bottom: 1px dashed #ccc; padding-bottom: 15px;">
                Analyzing Document: <strong>{os.path.basename(original_file)}</strong>
            </p>

            <div class="summary-box">
                <h2>✅ ANALYSIS SUMMARY</h2>
                <div class="conclusion">
                    CONCLUSION: {summary['conclusion']}
                </div>
                <p><strong>LIKELIHOOD ACCURACY:</strong> {summary['tamper_percentage']}% (Based on {len(sections['evidence'])} checks)</p>
            </div>

            <h2>### 1. Hex File & Signature Analysis</h2>
            <p><strong>File Signature:</strong> {sections['hex']['signature']}</p>
            <p><strong>First 16 Bytes (Hex):</strong> {sections['hex']['data']}</p>

            <h2>### 2. EXIF & Metadata Analysis</h2>
            {sections['metadata']['content']}
            
            <h2>### 3. Error Level Analysis (ELA)</h2>
            <p><strong>ELA result image saved:</strong> <code>{sections['ela']['output_filename']}</code></p>
            <p>🔑 <strong>Instruction:</strong> Manually check the saved ELA image for bright, inconsistent areas. </p>

            <h2>### EVIDENCE LIST (DETECT TAMPERED)</h2>
            <ul class="evidence-list">
                {sections['evidence']['content']}
            </ul>

        </div>
    </body>
    </html>
    """
    
    try:
        html_path = os.path.join(os.getcwd(), html_filename)
        with open(html_path, "w", encoding="utf-8") as f:
            f.write(html_content)
        return html_path
        
    except Exception as e:
        print(f"[HTML ERROR] Failed to save report: {e}")
        return None