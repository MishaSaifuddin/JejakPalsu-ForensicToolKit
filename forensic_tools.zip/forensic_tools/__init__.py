# forensic_tools/__init__.py

# This file makes the 'forensic_tools' directory a Python package.

from .ela import perform_ela
from .metadata_check import check_metadata, check_file_signature
from .dct_analysis import get_dct_coefficients

__all__ = [
    "perform_ela",
    "check_metadata",
    "check_file_signature",
    "get_dct_coefficients"
]